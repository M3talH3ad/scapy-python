from ip.IPLayer import IPLayer

class pyscapy(object):
	"""docstring for PacketConstuctor"""
	def __init__(self):
		# super(PacketConstuctor, self).__init__()
		self.arg = None


	def createIPPacket(self, arguments={}):
		return IPLayer(arguments)
		